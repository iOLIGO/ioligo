from .oligo import OLIGO, OLIGO5

__version__ = '1.0.0'

__all__ = ["OLIGO", "OLIGO5"]